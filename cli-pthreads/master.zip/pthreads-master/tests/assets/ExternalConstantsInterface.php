<?php

interface ExternalConstantsInterface{
	public const BUZZ = 1;
}
